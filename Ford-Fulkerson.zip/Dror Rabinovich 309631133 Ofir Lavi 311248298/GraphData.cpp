#include "GraphData.h"

GraphData::GraphData(int size) //c'tor
{
	p = new int[size];
	d = new int[size];
	heapLocation = new int[size];
	for (int i = 0;i < size;i++)
		heapLocation[i] = i;
	this->size = size;
}

GraphData::GraphData(GraphData && other) // move c'tor
{
	this->d = other.d;
	this->p = other.p;
	this->heapLocation = other.heapLocation;
	other.d = nullptr;
	other.p = nullptr;
	other.heapLocation = nullptr;
}

GraphData::~GraphData()  // d'tor
{
	delete[] d;
	delete[] p;
	delete[] heapLocation;
}

void GraphData::init()
{
	for (int i = 0; i < size; i++)
	{
		setD(i, START_VALUE);
		setP(i, START_VALUE);// -1 represent no perent
	}
}

void GraphData::printMinCat(int s) //  print 2 groups that represent the min cut
{
	cout << "The min cut: \nS: "<<s+1;
	for (int i = 0; i < size; i++)
	{
		if (p[i] != -1)
			cout << ", " << i+1;
	}
	cout << "\nT: ";
	for (int i = 0; i < size; i++)
	{
		if (p[i] ==-1 && i!=s)
			cout <<i+1<<", ";
	}
	cout << "\b\b";
}
