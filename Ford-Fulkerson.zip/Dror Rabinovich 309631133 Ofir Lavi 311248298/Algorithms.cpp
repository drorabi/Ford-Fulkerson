#include "Algorithms.h"


GraphData* Algorithms::bfs(Graph& G, int s)
{
	Queue Q;
	GraphData* data= new GraphData(G.getNumOfNodes());

	data->init();// make every d[i] =-1, p[i]=-1
	data->setD(s, 0);
	Q.enqueue(s);

	while (!Q.isEmpty())
	{
		int u = Q.dequeue();
		List<int>* adj = G.getAdjList(u);
		ListNode<int>* curr = adj->getHead();

		while (curr)
		{
			int v = curr->getNodeValue();
			if (data->getD(v) == _INFINITY)
			{
				data->setD(v, data->getD(u) + 1);
				data->setP(v, u);
				Q.enqueue(v);
			}
			curr = curr->getNext();
		}
		delete adj;
	}
	return data;
}

GraphData Algorithms::dijkstra(Graph& G, int s)
{
	int u;
	GraphData data(G.getNumOfNodes());

	data.init();// make every d[i] =-1, p[i]=-1
	data.setD(s, INT_MAX);
	MaxHeap maxPriorityQueue(G.getNumOfNodes(), &data); //create a Max Heap that use "data" as "key" and update the heap "pointers" inside data

	while (!maxPriorityQueue.isEmpty())
	{
		u = maxPriorityQueue.deleteMax();
		List<int>* adj = G.getAdjList(u);
		ListNode<int>* curr = adj->getHead();

		while (curr)
		{
			int v = curr->getNodeValue();
			int w =min( G.getEdge(u, v).getCapacity(), data.getD(u)); // takind the min between the edges from s till u, or the edge (u,v)
			
			if (data.getD(v) <w)  // our relax
			{
				data.setD(v,w);                   // increas the key inside the heap as well
				data.setP(v,u);           
				maxPriorityQueue.increaseKey(v); // update the new place of v after we increse the key 
			}
			curr = curr->getNext();
		}
		delete adj;
	}
	return data;	//return the perents Arr and the degree Arr
}

int Algorithms::min(int a, int b)
{
	if (a < b)
		return a;
	return b;
}