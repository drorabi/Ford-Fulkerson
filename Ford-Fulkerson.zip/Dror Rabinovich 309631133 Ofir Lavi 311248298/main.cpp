#include "Graph.h"
#include "MaxHeap.h"
#include "FileLoader.h"
#include "FordFulkerson.h"

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

/*
main function of the program:
-should get as argument file name.
The file context should be in the following format:
1. First row: Integer, "n", representing the number of vertex in the graph.
2. Second row: Integer, "m", representing the number of edges in the graph.
3. Third row: integer representing "s" (starting node in network between 1-n).
4. Forth row: Integer representing "t" (ending node in network between 1-n).
5. m rows: m times three integers, each three in a different row. every three integers representing an edge (i,j) by the following format:
		  -first integer-vertex "i".
		  -second integer-vertex "j".
		  -third integer-edge's capacity.
*/


using namespace std;

int main(int argc, char* argv[]) {
	FileLoader loader;
	Graph G = loader.openFile(argv[1]);
	cout << "Ford Fulkerson by BFS: " << endl;
	FordFulkerson::fordFulkersonByBFS(G, G.getS(), G.getT());
	cout << "Ford Fulkerson by greedy algorithm with dijkstra: " << endl;
	FordFulkerson::fordFulkersonByGreedyAlgorithm(G, G.getS(), G.getT());
}
