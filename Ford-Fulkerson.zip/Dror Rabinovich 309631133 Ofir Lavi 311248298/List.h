#pragma once

#ifndef __List_H
#define __List_H
#include "ListNode.h"
#include <iostream>

template<class T>
class List
{
	ListNode<T>* head;
	ListNode<T>* tail;
	int size;
public:

	List(ListNode<T>* node = nullptr);
	~List();
	//-------Getters------

	ListNode<T>* getHead() { return head; }
	ListNode<T>* getTail() { return tail; }
	int getSize() { return size; }

	//--------------------

	void insertToHead(ListNode<T>* node);
	void insertToTail(ListNode<T>* node);
	void deleteNode(ListNode<T>* node);
	void makeEmpty();
	bool isEmpty();
	bool find(ListNode<T>* node);
};



#endif // __List_H



template<class T>
List<T>::List(ListNode<T>* node)
	:size(0)
{
	this->head = node;
	this->tail = node;
}

template<class T>
inline List<T>::~List()
{
	ListNode<T>* curr = head;
	ListNode<T>* prev;

	while (curr)
	{
		prev = curr;
		curr = curr->getNext();
		delete prev;
	}
}

template<class T>
void List<T>::insertToHead(ListNode<T>* node)
{
	if (!this->isEmpty())
	{
		node->setNext(head);
		head = node;
		size++;
	}
	else
	{
		head = node;
		tail = node;
		size++;
	}
}

template<class T>
void List<T>::insertToTail(ListNode<T>* node)
{
	if (!this->isEmpty()) {
		tail->setNext(node);
		tail = node;
		size++;
	}
	else
	{
		head = node;
		tail = node;
		size++;
	}
}

template<class T>
void List<T>::deleteNode(ListNode<T>* node)
{
	ListNode<T>* curr = head;
	ListNode<T>* prev = curr;

	if (!this->isEmpty())
	{
		if (node == head)
		{
			head = curr->getNext();
			delete curr;
			return;
		}

		while (curr != node && curr != nullptr)
		{
			prev = curr;
			curr = curr->getNext();
		}

		if (curr == nullptr)
			return;

		prev->setNext(curr->getNext());
		delete curr;
	}

}

template<class T>
void List<T>::makeEmpty()
{
	ListNode<T>* curr = head;
	ListNode<T>* temp;
	while (curr != nullptr)
	{
		temp = curr;
		curr = curr->getNext();
		delete temp;
	}
}

template<class T>
bool List<T>::isEmpty()
{
	if (size > 0)
		return false;
	else
		return true;
}

template<class T>
bool List<T>::find(ListNode<T>* node)
{
	ListNode<T>* curr = head;

	while (curr != node && curr != nullptr)
		curr = curr->getNext();

	if (curr == nullptr)
		return false;
	else
		return true;
}
