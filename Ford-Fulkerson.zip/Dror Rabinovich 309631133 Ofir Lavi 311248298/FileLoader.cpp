#include "FileLoader.h"

Graph FileLoader::openFile(char * fileName)
{
	ifstream myfile(fileName);
	if (!myfile) {
		cerr << "Unable to open file datafile.txt";
		exit(1);   
	}

	Graph graph =creatGrapgFromFile(&myfile);

	myfile.close();
	return graph;
}



Graph  FileLoader::creatGrapgFromFile(ifstream * myfile)// return a graph from the file
{
	int numOfNodes, numOfEdges, s, t;

	numOfNodes = getAnIntFromFileAndCheckValid(myfile);
	numOfEdges = getAnIntFromFileAndCheckValid(myfile);
	Graph graph(numOfNodes);
	if (numOfNodes < 1 || numOfEdges < 1 || numOfEdges>(numOfNodes*numOfNodes - numOfNodes)) //max edges in simple graph is (n^2-n)
	{
		cout << "Invalid input";
		exit(1);
	}
	s = getAnIntFromFileAndCheckValid(myfile);
	t = getAnIntFromFileAndCheckValid(myfile);
	if ((s > numOfNodes || s < 1) || (t > numOfNodes || t < 1))  //check if s,t is in the graph
	{
		cout << "Invalid input";
		exit(1);
	}
	graph.setS(s - 1);
	graph.setT(t - 1);
	int from, to, w;

	for (int i = 0; i < numOfEdges; i++)  // add all edges
	{
		getEdgeInfo(myfile, &from, &to, &w);
		if (!isValidEdge(from, to, w, graph))  //return true if edge (from,to) is valid edge
		{
			cout << "Invalid input";
			exit(1);
		}
		graph.addEdge(from - 1, to - 1, w);
	}
	if (s == t)
	{
		cout << "S equal to T";
		exit(1);
	}
	return graph;
}

void FileLoader::getEdgeInfo(ifstream * myfile, int * from, int * to, int * weight)
{
	string singleLine;
	int countNumsInLine;
	*myfile >> *from;
	getline(*myfile, singleLine, '\n');
	countNumsInLine = 0;
	istringstream iss(singleLine);
	int tempNum;
	while (iss >> tempNum)
	{
		countNumsInLine++;
		if (countNumsInLine == 1)
		{
			*to = tempNum;
		}
		else if (countNumsInLine == 2) 
		{
			*weight = tempNum;
		}
		else if (countNumsInLine == 3)
		{
			cout << "Invalid input";
			exit(1);
		}
	}
	if (countNumsInLine != 2 || tempNum != *weight) {
		cout << "Invalid input";
		exit(1);
	}
}

int FileLoader::getAnIntFromFileAndCheckValid(ifstream * myfile)
{
	int retValue;
	string isAlonInRow, checkAlon;
	*myfile >> retValue;
	getline(*myfile, isAlonInRow, '\n');
	istringstream iss(isAlonInRow);
	if(iss >> checkAlon)
	{
		cout << "Invalid input";
		exit(1);
	}
	return retValue;
}


bool FileLoader::isValidEdge(int from, int to, int w,Graph& graph) { // check validation
	//checks self edge
	if (from == to)
		return false;
	//check in limits
	if ((from<1 || from>graph.getNumOfNodes()) || (to<1 || to>graph.getNumOfNodes()))
		return false;
	//check if edge already exists
	if (graph.isAdjacent(from-1,to-1))
		return false;
	if (w < 1)
		return false;
	return true;
}


