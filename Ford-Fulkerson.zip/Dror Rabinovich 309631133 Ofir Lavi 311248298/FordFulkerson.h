#pragma once
#ifndef __FORDFULKERSON_H
#define __FORDFULKERSON_H
#include "Algorithms.h"
#include "Graph.h"

using namespace std;

class FordFulkerson
{
private:

public:

	static void fordFulkersonByBFS(Graph &G, int s, int t);
	static void fordFulkersonByGreedyAlgorithm(Graph &G, int s, int t);
private:
	static int findCfP(Graph& Gf, GraphData& data, int t);
	static void updateF(int**f, GraphData &data, int t, int min);
	static void updateGf(Graph& Gf, Graph& G, GraphData& data, int**f, int t);
	static int** initFlow(int size);
	static void printMinCutAndMaxFlow(int s, GraphData& data, int ** f);
	static void deleteFlow(int** f,int size);
};

#endif // __FORDFULKERSON_