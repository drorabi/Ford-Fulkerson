#pragma once
#include <iostream>
#ifndef __DATA_H
#define __DATA_H
#include "ListNode.h"
using namespace std;
#define START_VALUE -1

class GraphData
{
	int* p;
	int* d;
	int* heapLocation;
	int size;
public:

	GraphData(int size = 0);
	GraphData(GraphData&& other);
	~GraphData();
	//-------Getters------

	int   getP(int node) { return p[node]; }
	int getD(int node) { return d[node]; }
	int getHeapLocation(int node) { return heapLocation[node]; }
	int getSize() { return size; }
	//------Setters-----

	void setP(int node, int num) { p[node] = num; }
	void setD(int node, int num) { d[node] = num; }
	void setHeapLocation(int node, int num) { heapLocation[node] = num; }

	//--------functions-----
	void init();
	void printMinCat(int s);

};


#endif // __Data_H

