#ifndef __MAXHEAP_H
#define __MAXHEAP_H
#include "GraphData.h"
#include "Edge.h"
#include <stdlib.h>
using namespace std;

class MaxHeap
{
private:
	int* heap;
	int _maxSize;
	int _heapSize;
	GraphData* data;
	bool _allocated;
	static int Left(int node) { return (node * 2) +1; }
	static int Right(int node) { return (node * 2) + 2; }
	static int Parent(int node) { return (node - 1) / 2; }
	void FixHeap(int node);
public:
	MaxHeap(int max);
	MaxHeap(int n, GraphData* data);
	~MaxHeap();


	void increaseKey(int v);
	int* getArr() { return heap; }
	int max() { return heap[0]; }
	int deleteMax();
	void insert(int GN);
	bool isEmpty() { return _heapSize==0; }
};
#endif // __MAXHEAP_H

