#include "Edge.h"

Edge::Edge(int u,int v, int capacity, int maxHeapPtr) :_u(u), _capacity(capacity){}

Edge::Edge(const Edge & other)
{
		*this = other;	
}

Edge::Edge(Edge && other)
{
	_u = other._u;
	_v = other._u;
	_capacity = other._capacity;
}


const Edge & Edge::operator=(const Edge & other)
{
	if (this != &other )
	{
		_u = other._u;
		_v = other._v;
		_capacity = other._capacity;
	}
	return *this;
}