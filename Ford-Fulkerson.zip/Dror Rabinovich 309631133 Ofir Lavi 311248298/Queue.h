#ifndef __QUEUE_H
#define __QUEUE_H

#include <iostream>
#include "ListNode.h"

using namespace std;

class Queue
{
private:
	ListNode<int>* head;
	ListNode<int>*	tail;
public:
	Queue();
	~Queue();
	void makeEmpty();
	bool isEmpty();
	void enqueue(int item);
	int front();
	int dequeue();
};



#endif // Queue.h