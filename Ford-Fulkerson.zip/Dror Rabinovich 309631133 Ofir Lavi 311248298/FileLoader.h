#pragma once
#ifndef __FILELOADER_H
#define __FILELOADER_H

#include <iostream>
#include "Graph.h"
#include "GraphData.h"
#include "MaxHeap.h"
#include <fstream>  /// ask michal about it
#include <string>
#include<sstream>


class FileLoader
{

public:
	Graph openFile(char *fileName);
private:
	Graph  creatGrapgFromFile(ifstream *myfile);
	bool isValidEdge(int from, int to, int w, Graph& graph);
	void getEdgeInfo(ifstream * myfile,int *from, int* to, int* wight);
	int getAnIntFromFileAndCheckValid(ifstream * myfile);
};

#endif // __FILELOADER_H