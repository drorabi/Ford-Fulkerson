#include "Queue.h"


Queue::Queue()
{
	head = nullptr;
	tail = head;
}

Queue::~Queue()
{
	makeEmpty();
}

void Queue::makeEmpty()
{
	ListNode<int>* curr = head;
	ListNode<int>* prev;

	while (curr)
	{
		prev = curr;
		curr = curr->getNext();
		delete prev;
	}
}

bool Queue::isEmpty()
{
	return head==nullptr;
}
void Queue::enqueue(int item)
{
	if (head == nullptr)
	{
		head= new ListNode<int>(item);
		tail = head;
	}
	else{
	ListNode<int>* node = new ListNode<int>(item);
	tail->setNext(node);
	tail = node;
	}
}

int Queue::front()
{
	if (isEmpty())
	{
		cout << "ERROR: QUEUE IS Empty\n" << endl;
		exit(-1);
	}
	return head->getNodeValue();

}

int Queue::dequeue()
{
	if (isEmpty())
	{
		cout << "ERROR: QUEUE IS Empty\n" << endl;
		exit(-1);
	}
	ListNode<int>* temp =head;
	head = head->getNext();
	int value = temp->getNodeValue();
	delete temp;
	return value;
}