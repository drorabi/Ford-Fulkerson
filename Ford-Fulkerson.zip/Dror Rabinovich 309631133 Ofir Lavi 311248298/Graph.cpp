#include "Graph.h"

Graph::Graph(int numOfNodes)
{
	allocateGraph(numOfNodes);
}


Graph::Graph(const Graph & other)
{
	*this = other;
}

Graph::Graph( Graph && other)
{
	this->graph = other.graph;
	other.graph=nullptr;
	this->s = other.s;
	this->t = other.t;
	_numOfNodes = other._numOfNodes;
	_numOfedges = other._numOfedges;
}

Graph::~Graph()
{
	deleteGraph();
}

void Graph::setCapacity(int from, int to, int capacity, int flow)
{
	graph[from][to].setCapacity(capacity - flow);
}

void Graph::makeEmptyGraph(int numOfNodes)
{
	deleteGraph();
	allocateGraph(numOfNodes);
}

bool Graph::isAdjacent(int u, int v)
{
	if (graph[u][v].getCapacity() > 0)
		return true;
	return false;
}

List<int>* Graph::getAdjList(const int u)
{
	ListNode<int>* curr;
	List<int>* adjList =new List<int>();
	int index;

	for (index = 0; index < _numOfNodes; index++)
	{
		if (this->graph[u][index].getCapacity() > 0) {
			curr = new ListNode<int>(index, nullptr);
			adjList->insertToTail(curr);
		}
	}
	return adjList;
}


void Graph::addEdge(int u, int v, int capacity)
{
	graph[u][v].setCapacity(capacity);
	graph[u][v].setNodes(u, v);
	_numOfedges++;
}

void Graph::removeEdge(int u, int v)
{
	graph[u][v].setCapacity(0);
}

const Graph & Graph::operator=(const Graph & other)
{
	this->graph = new Edge*[other._numOfNodes];
	for (int i = 0; i < other._numOfNodes; i++) {
		graph[i] = new Edge[other._numOfNodes];
		for (int j = 0; j < other._numOfNodes; j++) {
			graph[i][j].setNodes(i, j);
			graph[i][j].setCapacity(other.graph[i][j].getCapacity());
		}
	}
	this->s = other.s;
	this->t = other.t;
	_numOfNodes = other._numOfNodes;
	_numOfedges = other._numOfedges;
	return *this;
}

void Graph::deleteGraph()
{
	if(graph!=nullptr)
	{
	if (this->_numOfNodes > 0) {
		for (int i = 0; i < _numOfNodes; i++)
			delete[] graph[i];
		delete[] graph;
	}
	}
}

void Graph::allocateGraph(int numOfNodes)
{
	graph = new Edge*[numOfNodes];
	for (int i = 0; i < numOfNodes; i++){
		graph[i] = new Edge[numOfNodes];
		for (int j = 0; j < numOfNodes; j++){
			graph[i][j].setNodes(i, j);
		}
	}
	_numOfNodes = numOfNodes;
	
}

