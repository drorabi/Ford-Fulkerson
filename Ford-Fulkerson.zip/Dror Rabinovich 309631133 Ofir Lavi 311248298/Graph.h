#pragma once
#ifndef __GRAPH_H
#define __GRAPH_H
#include <iostream>
#include <stdlib.h>
#include "Edge.h"
#include "List.h"
#include <fstream>  /// ask michal about it, but first Dror will ask shani right now <3

using namespace std;

class Graph
{
private:
	Edge**  graph;
	int     _numOfNodes;
	int     _numOfedges;
	int s;
	int t;

public:
	Graph(int numOfNodes);
	Graph(const Graph& other);
	Graph(Graph&& other);
	~Graph();

	void setCapacity(int from, int to, int capacity, int flow);
	void makeEmptyGraph(int numOfNodes);
	bool isAdjacent(int u, int v);
	void addEdge(int u, int v, int capacity);
	void removeEdge(int u, int v);

	//------------

	//-------------Getters------------//

	Edge getEdge(int u, int v) { return graph[u][v]; }
	List<int>* getAdjList(const int u);
    int getNumOfNodes() {return _numOfNodes;}
	int getNumOfEdges() {return _numOfedges;}
	int getS() { return this->s; }
	int getT() { return this->t; }
	//-------------Setters-----------//
	void setS(int s) {this->s = s;}
	void setT(int t) { this->t = t; }

	//--------------Operator--------------//
	const Graph& operator=(const Graph& other);
	
private:
	void deleteGraph();
	void allocateGraph(int size);

};

#endif // __GRAPH_H