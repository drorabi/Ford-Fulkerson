#include "MaxHeap.h"

void MaxHeap::FixHeap(int node)
{
	int max;
	int left = Left(node);
	int right = Right(node);

	if ((left < _heapSize) && (data->getD(heap[left]) > data->getD(heap[node])))
		max = left;
	else
		max = node;
	if ((right < _heapSize) && (data->getD(heap[right]) > data->getD(heap[max])))
		max = right;
	
	if (max != node)
	{
		swap(heap[node], heap[max]);
		data->setHeapLocation(heap[node],node);  //update where vetrex node in the heap
		data->setHeapLocation(heap[max], max);
		FixHeap(max);
	}
}

MaxHeap::MaxHeap(int max)
{
	heap = new int[max];
	_maxSize = max;
	_heapSize = 0;
	_allocated = true;
}

MaxHeap::MaxHeap(int n, GraphData* data)
{
	int i;
	this->data = data;
	_heapSize = n;
	_maxSize = n;
	heap = new int[n];
	for ( i = 0;i < n;i++)
		heap[i] = i;
	_allocated = true;
	for (int j = (n / 2) - 1;j >= 0;j--)
		FixHeap(j);
}

MaxHeap::~MaxHeap()
{
	if (_allocated)
		delete[] heap;
	heap = nullptr;
}


void MaxHeap::increaseKey(int v)
{
	int i=data->getHeapLocation(v);
	while ((i > 0) && (data->getD(heap[Parent(i)]) < data->getD(v)))
	{
		heap[i] = heap[Parent(i)];
		data->setHeapLocation(heap[i], i);  //update where vetrex node in the heap
		i = Parent(i);
	}
	heap[i] = v;
	data->setHeapLocation(heap[i], i); 
}

int MaxHeap::deleteMax()
{
	if (_heapSize < 1)
	{
		cout << "Error:EMPTY HEAP \n";
		exit(-1);
	}
	int max=heap[0];
	_heapSize--;
	heap[0] = heap[_heapSize];
	data->setHeapLocation(heap[_heapSize], 0); //update where vetrex node in the heap
	FixHeap(0);
	return max;
}

void MaxHeap::insert(int graphNode)
{
	if (_heapSize == _maxSize)
	{
		cout << "ERROR HEAP FULL \n";
		exit(-1);
	}
	int i = _heapSize;
	_heapSize++;
	while ((i > 0) && (data->getD(heap[Parent(i)]) <data->getD(graphNode)))
	{
		heap[i] = heap[Parent(i)];
		data->setHeapLocation(heap[i], i); //update where vetrex node in the heap
		i = Parent(i);
	}
	heap[i] = graphNode;
	data->setHeapLocation(heap[i], i);
}
