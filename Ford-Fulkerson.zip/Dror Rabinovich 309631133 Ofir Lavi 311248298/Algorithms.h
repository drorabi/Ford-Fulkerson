#pragma once
#ifndef __ALGORITHMS_H
#define __ALGORITHMS_H

#include <iostream>
#include "Graph.h"
#include "GraphData.h"
#include "MaxHeap.h"
#include "Queue.h"
const int _INFINITY = -1;
#define _NULL  -1;

class Algorithms
{
	
public:
	
    static GraphData* bfs(Graph& G, int s);
	static GraphData dijkstra(Graph& G, int s);

private:
	static int min(int a, int b);
};

#endif // __ALGORITHMS_H