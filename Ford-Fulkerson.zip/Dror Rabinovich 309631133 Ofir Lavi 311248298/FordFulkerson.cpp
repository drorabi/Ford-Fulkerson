#include "FordFulkerson.h"

void FordFulkerson::fordFulkersonByBFS(Graph& G, int s, int t)
{
	int numOfIteraitions=0; // "numOfIteraitions" count only the improver routh
	bool betterRouteExist = true; 
	int **f = initFlow(G.getNumOfNodes());
	Graph Gf(G);   // Gf is the Residual (shiori) graph
	GraphData* data; // data keep the perents Arr and the degree Arr
	do
	{
		int u = t, min;
		data = Algorithms::bfs(Gf, s); // to find a route between s and t
		if (data->getP(t) != -1)  // if (there is a route) continue
		{
			numOfIteraitions++;
			min = findCfP(Gf, *data, t); //find min capacity on route
			updateF(f, *data, t, min);
			updateGf(Gf, G, *data, f, t);
			delete data;
		}
		else {        
			betterRouteExist = false;
			cout << "The num of iterations is " << numOfIteraitions << endl;
			printMinCutAndMaxFlow(s, *data, f);
			delete data;
		}
	} while (betterRouteExist);
	deleteFlow(f, G.getNumOfNodes());
	
}

void FordFulkerson::fordFulkersonByGreedyAlgorithm(Graph &G, int s, int t)
{
	int numOfIteraitions = 0;   // "numOfIteraitions" count only the improver routh
	bool betterRouteExist = true;
	int **f = initFlow(G.getNumOfNodes());
	Graph Gf(G);    // Gf is the Residual (shiori) graph
	do
	{
		int u = t, min = INT_MAX;
		GraphData data = Algorithms::dijkstra(Gf, s);  // data keep the perents Arr and the degree Arr 
		if (data.getP(t) != -1)   // if (there is a route) continue
		{
			numOfIteraitions++;
			min = findCfP(Gf, data, t); //find min capacity on route
			updateF(f, data, t, min);
			updateGf(Gf, G, data, f, t);
		}
		else {
			betterRouteExist = false;
			cout << "The num of iterations is " << numOfIteraitions << endl;
			GraphData* data = Algorithms::bfs(Gf, s);
			printMinCutAndMaxFlow(s, *data, f);
			delete data;
		}
	} while (betterRouteExist);
	deleteFlow(f, G.getNumOfNodes());
}


int FordFulkerson::findCfP(Graph& Gf,GraphData& data,int t) //find min capacity on route
{
	int u = t;
	int min = INT_MAX;
	while (data.getP(u) != -1)   
	{
		if (min > Gf.getEdge(data.getP(u), u).getCapacity())
			min = Gf.getEdge(data.getP(u), u).getCapacity();
		u = data.getP(u);
	}
	return min;
}

void FordFulkerson::updateF(int ** f,GraphData &data, int t, int min)  // update the flow function
{
	int u = t;
	while (data.getP(u) != -1)
	{
		f[data.getP(u)][u] += min;
		f[u][data.getP(u)] = -f[data.getP(u)][u];
		u = data.getP(u);
	}
}

void FordFulkerson::updateGf(Graph & Gf, Graph & G, GraphData& data, int ** f, int t) // update the capacity of Gf edges
{
	int u = t;
	while (data.getP(u) != -1)
	{
		Gf.setCapacity(data.getP(u), u, G.getEdge(data.getP(u), u).getCapacity(), f[data.getP(u)][u]);
		Gf.setCapacity(u, data.getP(u), G.getEdge(u, data.getP(u)).getCapacity(), f[u][data.getP(u)]);
		u = data.getP(u);
	}
}

int ** FordFulkerson::initFlow(int size)  // start the flow function to f[i][j]=0 
{
	int**f = new int*[size];
	int i;
	for (i = 0; i < size; i++)
		f[i] = new int[size];
	// init f
	for (i = 0; i < size; i++)
		for (int j = 0; j < size; j++)
			f[i][j] = 0;
	return f;
}

void FordFulkerson::printMinCutAndMaxFlow(int s,GraphData& data,int ** f) // print 2 groups that represent the min cut and max flow of G
{
	data.printMinCat(s);
	int maxFlowSum = 0;
	for (int i = 0; i <data.getSize(); i++)
		maxFlowSum += f[s][i];
	cout << "\nThe max flow is " << maxFlowSum<<endl<<endl;
}

void FordFulkerson::deleteFlow(int ** f,int size)
{
	for (int i = 0; i < size; i++)
		delete[] f[i];
	delete[] f;
}

