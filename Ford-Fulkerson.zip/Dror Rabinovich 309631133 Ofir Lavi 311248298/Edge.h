#pragma once

#include <iostream>
#ifndef __EDGE_H
#define __EDGE_H

class Edge
{
	int _capacity=0;
	int _u;
	int _v;
public:
	Edge() {};
	Edge(int u,int v,int capacity = 0, int maxHeapPtr = -1);
	Edge(const Edge& other);
	Edge(Edge&& other);


	//--------------Getters-----------------//
	int getCapacity() const { return _capacity; }
	int getFrom() const { return _u; }
	int getTo() const { return _v; }

	//--------------Setters----------------//
	void setCapacity(int capacity) { _capacity = capacity; }
	void setNodes(int u, int v) { _u = u; _v = v; }

	//--------------Operator--------------//
	const Edge& operator=(const Edge& other);

};



#endif // __EDGE_H