#pragma once
#ifndef __LISTNODE_H
#define __LISTNODE_H
#include "Edge.h"
#include <iostream>


template <class T>
class ListNode
{
	T value;
	ListNode*  next;
public:

	ListNode()=default;
	ListNode(const T value , ListNode* node = nullptr);
	~ListNode() = default;

	//--------------Getters-----------------//
	ListNode<T>* getNext() const { return next; }
	T getNodeValue() const { return value; }

	//--------------------------------//

	void setNext(ListNode<T>* node);
};
#endif // __LISTNODE_H
template<class T>
ListNode<T>::ListNode(const T value, ListNode*  node)
	:value(value), next(node) {}

template<class T>
void ListNode<T>::setNext(ListNode* node)
{
	next = node;
}

